from django.shortcuts import render,redirect
from django.http import HttpResponse,JsonResponse
from django.shortcuts import loader
from .models import category,products,Cart
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.forms import UserCreationForm
# Create your views here.

def Welcom(request):
    return HttpResponse('اهلا بكم في دروس جانقو')

def LandPage(request):
    Category=category.objects.all()
    context={
       'data':Category
    }
    return render(request,'landPage.html',context)
  

def GetData(request):
   data={
      'name':'احمد',
      'age':25,
      'skills':['python','django','HTML'],
   }
   return JsonResponse(data)

def datasend(request,name):
   return HttpResponse(name)
def Add(request,d1,d2):
  return HttpResponse(d1+d2)

def runindex(request):
   template=loader.get_template('index.html')
   return HttpResponse(template.render())

def AbouUs(request):
   template=loader.get_template('aboutUs.html')
   return HttpResponse(template.render())

def invoice(request):
   if request.method=="POST":
      phone_id=request.POST.get("phone_id")
      full_name=request.POST.get("full_name")
      phone=request.POST.get("phone")
      email=request.POST.get("email")
   phones=[
      {
         "id":"001",
         "name":"iphone 15 pro",
         "brand":"Apple",
         "price":4599,
         "storage":"255GB",
         "color":"Wihte",
         "image":"images/iphon15.jpg",

      },
      {
         "id":"002",
         "name":"Galaxy s24 ultra",
         "brand":"samsung",
         "price":4599,
         "storage":"255GB",
         "color":"Gray",
         "image":"images/galaxy_s24.jpg",
         },
         {
            "id":"003",
         "name":"pixle 8 pro",
         "brand":"Google",
         "price":4599,
         "storage":"255GB",
         "color":"blue",
         "image":"images/pixel8.jpg",
         },
        
   ]
   phone=[p for p in phones if str(p["id"])==str(phone_id)]
   return render(request,"invoice.html",{
       "full_name":full_name,
       "phone":phone,
       "email":email,
       "product":phone
    })

def blog(request):
   template=loader.get_template('blog.html')
   return HttpResponse(template.render())

def phonemenue(request):
   phon_id=request.GET.get("id")
   product=products.objects.filter(category_id=phon_id)
   context={
      'product':product
   }
   return render(request,"phoneMenue.html",context)

def details(request):
   phone_id=request.GET.get("id")
   product=products.objects.filter(category_id=phone_id)
   context={
      'product':product
   }
   return render(request,"detailes.html",context)

def addToCart(request):
   product=request.GET.get("id")
   cart_item,created=Cart.objects.get_or_create(
      product_id=product ,
      defaults={'quantity':1}
   )     
   if not created:
    cart_item.quantity +=1
    cart_item.save()
    
    product=products.objects.filter(id=product)
    context={
       "product":product
    }
    return render(request,"detailes.html",context)

@login_required(login_url='authLogin')
def checkout(request):
  cart=Cart.objects.select_related('product').all()

  context={
  'cart' :cart
  }
  return render(request,'checkOut.html',context)


def authLogin(request):
  template=loader.get_template('auth/auth_login.html')
  return HttpResponse(template.render())

def authRegister(request):
  template=loader.get_template('auth/auth_register.html')
  print(request.method)
  if request.method=="post":
    form=UserCreationForm(request.POST)
    if form.is_valid():
       form.save()
       return redirect('authLogin')
    else:
       form=UserCreationForm()
  
  return render(request,'auth_register.html',{'form':form})